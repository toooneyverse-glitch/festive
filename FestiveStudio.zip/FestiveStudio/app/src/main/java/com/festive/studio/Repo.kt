package com.festive.studio

import android.content.Context
import androidx.compose.runtime.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.time.ZonedDateTime

/** Single on-device store. Everything lives in filesDir/state.json - no network, no server. */
class Repo private constructor(ctx: Context) {
    val events = mutableStateListOf<Event>()
    val campaigns = mutableStateListOf<Campaign>()
    val contacts = mutableStateListOf<Contact>()
    val alerts = mutableStateListOf<Alert>()
    val sentKeys = mutableStateListOf<String>()      // "campaignId|lang|phone"
    val history = mutableListOf<Hist>()
    private val auditLog = mutableListOf<JSONObject>()
    var nextId = 1; private set
    var notifyHour by mutableIntStateOf(8)
    var notifyMinute by mutableIntStateOf(0)
    var thoughtEnabled by mutableStateOf(true)
    var ownerName by mutableStateOf("Owner")
    var lastRun by mutableStateOf("")

    private val file = File(ctx.filesDir, "state.json")
    val cardsDir = File(ctx.filesDir, "cards").apply { mkdirs() }

    companion object {
        @Volatile private var inst: Repo? = null
        fun get(ctx: Context): Repo = inst ?: synchronized(this) { inst ?: Repo(ctx.applicationContext).also { inst = it } }
    }

    init {
        load()
        // seed + keep fixed-date occasions available for this year and the next two
        val have = events.map { it.key + it.date }.toSet()
        val year = ZonedDateTime.now(IST).year
        val seed = CalendarData.verified() + (year..year + 2).flatMap { CalendarData.fixedFor(it) }
        seed.filter { (it.key + it.date) !in have }.forEach { events.add(it) }
        save()
    }

    fun now(): String = ZonedDateTime.now(IST).toString().substringBefore('[')
    @Synchronized fun newId(): Int = nextId++

    fun putCampaign(c: Campaign) {
        val i = campaigns.indexOfFirst { it.id == c.id }
        if (i >= 0) campaigns[i] = c else campaigns.add(c)
        save()
    }
    fun putEvent(e: Event, replaceKey: String? = null) {
        val i = events.indexOfFirst { it.key + it.date == (replaceKey ?: (e.key + e.date)) }
        if (i >= 0) events[i] = e else events.add(e)
        save()
    }
    fun addAlert(key: String, kind: String, message: String) {
        if (alerts.any { it.key == key }) return
        alerts.add(Alert(key, kind, message, now())); save()
    }
    fun dismissAlert(key: String) {
        val i = alerts.indexOfFirst { it.key == key }
        if (i >= 0) { alerts[i] = alerts[i].copy(dismissed = true); save() }
    }

    // ---- tamper-evident audit trail (hash chain) ----
    private fun sha(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    @Synchronized fun audit(actor: String, action: String, detail: String = "") {
        val prev = auditLog.lastOrNull()?.getString("hash") ?: "GENESIS"
        val at = now()
        auditLog.add(JSONObject().put("at", at).put("actor", actor).put("action", action).put("detail", detail)
            .put("prev", prev).put("hash", sha("$prev|$at|$actor|$action|$detail")))
        save()
    }
    fun auditCount() = auditLog.size
    fun verifyAudit(): Boolean {
        var prev = "GENESIS"
        for (r in auditLog) {
            val h = sha("$prev|${r.getString("at")}|${r.getString("actor")}|${r.getString("action")}|${r.getString("detail")}")
            if (r.getString("prev") != prev || r.getString("hash") != h) return false
            prev = h
        }
        return true
    }
    fun auditLines(n: Int = 30): List<String> = auditLog.takeLast(n).reversed().map { "${it.getString("at").take(16)}  ${it.getString("actor")}: ${it.getString("action")} ${it.getString("detail")}" }

    // ---- persistence ----
    @Synchronized fun save() {
        val o = JSONObject()
            .put("nextId", nextId).put("hour", notifyHour).put("minute", notifyMinute)
            .put("thought", thoughtEnabled).put("owner", ownerName).put("lastRun", lastRun)
        o.put("events", JSONArray().also { a -> events.toList().forEach { e -> a.put(JSONObject().put("key", e.key).put("date", e.date).put("nameEn", e.nameEn).put("nameHi", e.nameHi).put("status", e.status).put("source", e.source).put("note", e.note)) } })
        o.put("campaigns", JSONArray().also { a -> campaigns.toList().forEach { c ->
            a.put(JSONObject().put("id", c.id).put("brand", c.brand).put("occasion", c.occasion).put("eventDate", c.eventDate).put("status", c.status).put("attempts", c.attempts)
                .put("approvedBy", c.approvedBy).put("approvedAt", c.approvedAt)
                .put("images", JSONArray().also { ia -> c.images.forEach { i -> ia.put(JSONObject().put("lang", i.lang).put("file", i.file).put("l1", i.l1).put("l2", i.l2).put("source", i.source).put("qa", i.qa)) } }))
        } })
        o.put("contacts", JSONArray().also { a -> contacts.toList().forEach { c -> a.put(JSONObject().put("name", c.name).put("phone", c.phone).put("brand", c.brand).put("lang", c.lang).put("consent", c.consent).put("optedOut", c.optedOut)) } })
        o.put("alerts", JSONArray().also { a -> alerts.toList().forEach { x -> a.put(JSONObject().put("key", x.key).put("kind", x.kind).put("message", x.message).put("at", x.at).put("dismissed", x.dismissed)) } })
        o.put("sent", JSONArray(sentKeys.toList()))
        o.put("history", JSONArray().also { a -> history.toList().forEach { h -> a.put(JSONObject().put("brand", h.brand).put("occasion", h.occasion).put("lang", h.lang).put("l1", h.l1).put("l2", h.l2)) } })
        o.put("audit", JSONArray().also { a -> auditLog.forEach { a.put(it) } })
        file.writeText(o.toString())
    }

    private fun load() {
        if (!file.exists()) return
        try {
            val o = JSONObject(file.readText())
            nextId = o.optInt("nextId", 1); notifyHour = o.optInt("hour", 8); notifyMinute = o.optInt("minute", 0)
            thoughtEnabled = o.optBoolean("thought", true); ownerName = o.optString("owner", "Owner"); lastRun = o.optString("lastRun", "")
            o.optJSONArray("events")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { e -> events.add(Event(e.getString("key"), e.getString("date"), e.getString("nameEn"), e.getString("nameHi"), e.getString("status"), e.getString("source"), e.optString("note"))) } }
            o.optJSONArray("campaigns")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { c ->
                val imgs = mutableListOf<CardImage>(); val ia = c.getJSONArray("images")
                for (j in 0 until ia.length()) ia.getJSONObject(j).let { m -> imgs.add(CardImage(m.getString("lang"), m.getString("file"), m.getString("l1"), m.getString("l2"), m.getString("source"), m.getString("qa"))) }
                campaigns.add(Campaign(c.getInt("id"), c.getString("brand"), c.getString("occasion"), c.getString("eventDate"), c.getString("status"), c.getInt("attempts"), imgs, c.optString("approvedBy"), c.optString("approvedAt")))
            } }
            o.optJSONArray("contacts")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { c -> contacts.add(Contact(c.getString("name"), c.getString("phone"), c.getString("brand"), c.getString("lang"), c.getBoolean("consent"), c.getBoolean("optedOut"))) } }
            o.optJSONArray("alerts")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { x -> alerts.add(Alert(x.getString("key"), x.getString("kind"), x.getString("message"), x.getString("at"), x.optBoolean("dismissed"))) } }
            o.optJSONArray("sent")?.let { a -> for (i in 0 until a.length()) sentKeys.add(a.getString(i)) }
            o.optJSONArray("history")?.let { a -> for (i in 0 until a.length()) a.getJSONObject(i).let { h -> history.add(Hist(h.getString("brand"), h.getString("occasion"), h.getString("lang"), h.getString("l1"), h.getString("l2"))) } }
            o.optJSONArray("audit")?.let { a -> for (i in 0 until a.length()) auditLog.add(a.getJSONObject(i)) }
        } catch (e: Exception) {
            file.renameTo(File(file.parentFile, "state.corrupt.${System.currentTimeMillis()}.json"))
        }
    }
}
