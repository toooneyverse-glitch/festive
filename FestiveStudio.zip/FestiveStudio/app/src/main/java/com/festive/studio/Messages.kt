package com.festive.studio

import kotlin.random.Random

enum class Motif { DIYA, TRICOLOUR, DROPS, LEAVES, SPLASH, STARS, NONE }

data class Occ(
    val key: String, val nameEn: String, val nameHi: String, val titleEn: String, val titleHi: String, val motif: Motif,
    val en1: List<String>, val en2: List<String>, val hi1: List<String>, val hi2: List<String>
)

/**
 * On-device "creative mind": a rule-based generator. Each occasion has opening and closing lines in English and Hindi;
 * the generator combines them, avoids pairs already used for that company, and validates every result.
 * (No internet, no AI model - variety is limited to what is written here.)
 */
object Messages {
    private fun o(key: String, en: String, hi: String, m: Motif, e1: List<String>, e2: List<String>, h1: List<String>, h2: List<String>,
                  tEn: String = "Happy $en", tHi: String = "शुभ $hi") = Occ(key, en, hi, tEn, tHi, m, e1, e2, h1, h2)

    val occasions: Map<String, Occ> = listOf(
        o("diwali", "Diwali", "दीपावली", Motif.DIYA,
            listOf("Wishing you and your family a joyous and prosperous Diwali.", "May the light of Diwali bring new opportunities and lasting success.", "On this festival of lights, may every home glow with happiness and good health."),
            listOf("May the festival of lights bring happiness, success and endless possibilities.", "Wishing you warmth, good health and steady growth in the year ahead.", "May this Diwali brighten every step of your journey ahead."),
            listOf("आपको एवं आपके परिवार को दीपावली की हार्दिक शुभकामनाएँ।", "दीपावली का प्रकाश आपके जीवन में नई आशाएँ और सफलता लेकर आए।", "इस दीपोत्सव पर आपका घर खुशियों की रोशनी से जगमगाता रहे।"),
            listOf("दीपों का यह पावन पर्व आपके जीवन में सुख, समृद्धि और खुशियाँ लेकर आए।", "आपको अच्छे स्वास्थ्य, सुख और निरंतर उन्नति की शुभकामनाएँ।", "यह दीपावली आपके हर कदम को नई रोशनी से भर दे।")),
        o("dhanteras", "Dhanteras", "धनतेरस", Motif.DIYA,
            listOf("Wishing you and your family a blessed and prosperous Dhanteras.", "May Dhanteras bring good health, wealth and lasting well-being to your home."),
            listOf("May this auspicious day open the door to a year of steady growth.", "Warm wishes for happiness, good fortune and success ahead."),
            listOf("आपको एवं आपके परिवार को धनतेरस की हार्दिक शुभकामनाएँ।", "धनतेरस का यह शुभ दिन आपके घर में सुख, समृद्धि और अच्छा स्वास्थ्य लाए।"),
            listOf("यह पावन अवसर आपके जीवन में निरंतर उन्नति के द्वार खोले।", "आपको खुशहाली, सौभाग्य और सफलता की अनेक शुभकामनाएँ।")),
        o("govardhan_puja", "Govardhan Puja", "गोवर्धन पूजा", Motif.DIYA,
            listOf("Wishing you and your family a blessed Govardhan Puja.", "May the spirit of Govardhan Puja fill your home with gratitude and abundance."),
            listOf("May devotion and togetherness bring happiness to every day ahead.", "Warm wishes for good health, harmony and prosperity."),
            listOf("आपको एवं आपके परिवार को गोवर्धन पूजा की हार्दिक शुभकामनाएँ।", "गोवर्धन पूजा का पावन पर्व आपके घर को कृतज्ञता और समृद्धि से भर दे।"),
            listOf("श्रद्धा और एकता आपके हर दिन में खुशियाँ लेकर आए।", "आपको अच्छे स्वास्थ्य, सद्भाव और समृद्धि की शुभकामनाएँ।")),
        o("bhai_dooj", "Bhai Dooj", "भाई दूज", Motif.DIYA,
            listOf("Wishing you a joyful Bhai Dooj filled with love and togetherness.", "On Bhai Dooj, may the bond between siblings grow stronger every year."),
            listOf("May your family be blessed with happiness, health and harmony.", "Warm wishes to you and your loved ones."),
            listOf("आपको भाई दूज की हार्दिक शुभकामनाएँ, प्रेम और अपनत्व से भरा यह दिन मंगलमय हो।", "भाई दूज पर भाई-बहन का स्नेह हर वर्ष और गहरा होता रहे।"),
            listOf("आपका परिवार सुख, स्वास्थ्य और सद्भाव से भरा रहे।", "आपको एवं आपके प्रियजनों को सादर शुभकामनाएँ।")),
        o("chhath_puja", "Chhath Puja", "छठ पूजा", Motif.STARS,
            listOf("Wishing you and your family a blessed and joyful Chhath Puja.", "May the Sun's blessings on Chhath Puja bring you strength and good health."),
            listOf("May devotion and discipline bring peace and prosperity to your home.", "Warm wishes for a bright and fulfilling year ahead."),
            listOf("आपको एवं आपके परिवार को छठ पूजा की हार्दिक शुभकामनाएँ।", "छठ पूजा पर सूर्य देव की कृपा आपको शक्ति और उत्तम स्वास्थ्य प्रदान करे।"),
            listOf("श्रद्धा और संयम आपके घर में शांति और समृद्धि लेकर आएँ।", "आगामी वर्ष आपके लिए उज्ज्वल और सफल हो, यही शुभकामना है।")),
        o("republic_day", "Republic Day", "गणतंत्र दिवस", Motif.TRICOLOUR,
            listOf("Warm wishes on Republic Day to you and your family.", "On Republic Day, let us celebrate the values that bind our nation together."),
            listOf("Together, may we keep building a strong and progressive India.", "May our work always reflect integrity and national pride."),
            listOf("आपको एवं आपके परिवार को गणतंत्र दिवस की हार्दिक शुभकामनाएँ।", "गणतंत्र दिवस पर आइए उन मूल्यों का सम्मान करें जो हमारे देश को एक सूत्र में बाँधते हैं।"),
            listOf("हम सब मिलकर एक सशक्त, एकजुट और प्रगतिशील भारत का निर्माण करते रहें।", "हमारा हर कार्य ईमानदारी और राष्ट्र-गौरव का प्रतीक बने।"),
            tHi = "गणतंत्र दिवस की शुभकामनाएँ"),
        o("independence_day", "Independence Day", "स्वतंत्रता दिवस", Motif.TRICOLOUR,
            listOf("Warm wishes on Independence Day to you and your family.", "On Independence Day, we honour the freedom and sacrifices that shaped our nation."),
            listOf("May we keep building an India we are proud of, one honest effort at a time.", "Together, let us work for a stronger and more prosperous nation."),
            listOf("आपको एवं आपके परिवार को स्वतंत्रता दिवस की हार्दिक शुभकामनाएँ।", "स्वतंत्रता दिवस पर हम उन बलिदानों को नमन करते हैं जिन्होंने हमें आज़ादी दिलाई।"),
            listOf("आइए ईमानदार प्रयासों से एक ऐसा भारत गढ़ें जिस पर हमें गर्व हो।", "हम सब मिलकर एक सशक्त और समृद्ध राष्ट्र के लिए कार्य करें।"),
            tHi = "स्वतंत्रता दिवस की शुभकामनाएँ"),
        o("gandhi_jayanti", "Gandhi Jayanti", "गांधी जयंती", Motif.STARS,
            listOf("Remembering Mahatma Gandhi on Gandhi Jayanti.", "On Gandhi Jayanti, we honour a life of truth, simplicity and service."),
            listOf("May his ideals of integrity and non-violence guide our work every day.", "Wishing you peace, purpose and goodwill."),
            listOf("गांधी जयंती पर महात्मा गांधी को सादर नमन।", "गांधी जयंती पर हम सत्य, सादगी और सेवा से भरे जीवन को याद करते हैं।"),
            listOf("उनके सत्य और अहिंसा के आदर्श हमारे हर कार्य को दिशा दें।", "आपको शांति, उद्देश्य और सद्भावना की शुभकामनाएँ।"),
            tEn = "Gandhi Jayanti", tHi = "गांधी जयंती"),
        o("new_year", "New Year", "नववर्ष", Motif.STARS,
            listOf("Wishing you and your family a happy and prosperous New Year.", "May the New Year bring you good health, joy and new opportunities."),
            listOf("Thank you for your trust and partnership; we look forward to growing together.", "May every day ahead be filled with progress and purpose."),
            listOf("आपको एवं आपके परिवार को नववर्ष की हार्दिक शुभकामनाएँ।", "नया वर्ष आपके जीवन में अच्छा स्वास्थ्य, खुशियाँ और नए अवसर लेकर आए।"),
            listOf("आपके विश्वास और साथ के लिए धन्यवाद; हम साथ मिलकर आगे बढ़ने की आशा रखते हैं।", "आने वाला हर दिन प्रगति और उद्देश्य से भरा रहे।"),
            tHi = "शुभ नववर्ष"),
        o("new_financial_year", "New Financial Year", "नया वित्तीय वर्ष", Motif.STARS,
            listOf("Wishing you a successful and rewarding new financial year.", "May the new financial year bring steady growth and fresh opportunities."),
            listOf("Thank you for your trust; we look forward to serving you better.", "Here is to a year of strong partnerships and shared success."),
            listOf("आपको नए वित्तीय वर्ष की हार्दिक शुभकामनाएँ, यह वर्ष सफल और फलदायी हो।", "नया वित्तीय वर्ष आपके लिए स्थिर उन्नति और नए अवसर लेकर आए।"),
            listOf("आपके भरोसे के लिए धन्यवाद; हम और बेहतर सेवा के लिए प्रयासरत रहेंगे।", "यह वर्ष मज़बूत साझेदारियों और साझा सफलता का वर्ष हो।"),
            tHi = "नया वित्तीय वर्ष मंगलमय हो"),
        o("world_water_day", "World Water Day", "विश्व जल दिवस", Motif.DROPS,
            listOf("On World Water Day, let us remember that every drop counts.", "Clean water is the foundation of healthy homes and a healthy planet."),
            listOf("Let us store it wisely, use it carefully and protect it for the future.", "Small steps in water conservation create lasting change."),
            listOf("विश्व जल दिवस पर याद रखें कि हर एक बूँद कीमती है।", "स्वच्छ जल स्वस्थ घरों और स्वस्थ पृथ्वी की बुनियाद है।"),
            listOf("आइए जल को समझदारी से संजोएँ, सावधानी से उपयोग करें और भविष्य के लिए बचाएँ।", "जल संरक्षण के छोटे-छोटे कदम स्थायी बदलाव लाते हैं।"),
            tEn = "World Water Day", tHi = "विश्व जल दिवस"),
        o("world_environment_day", "World Environment Day", "विश्व पर्यावरण दिवस", Motif.LEAVES,
            listOf("On World Environment Day, let us pledge to protect the planet we share.", "A greener tomorrow begins with the choices we make today."),
            listOf("Small, responsible actions can create a cleaner and healthier future.", "Together, let us build with care for nature."),
            listOf("विश्व पर्यावरण दिवस पर आइए अपनी साझा धरती की रक्षा का संकल्प लें।", "एक हरा-भरा कल आज हमारे लिए गए निर्णयों से शुरू होता है।"),
            listOf("छोटे-छोटे ज़िम्मेदार कदम एक स्वच्छ और स्वस्थ भविष्य बना सकते हैं।", "आइए प्रकृति का ध्यान रखते हुए आगे बढ़ें।"),
            tEn = "World Environment Day", tHi = "विश्व पर्यावरण दिवस"),
        o("engineers_day", "Engineers' Day", "अभियंता दिवस", Motif.STARS,
            listOf("Happy Engineers' Day to everyone who builds with skill and care.", "On Engineers' Day, we salute the minds that turn ideas into reliable reality."),
            listOf("Thank you for the precision, patience and passion you bring to your work.", "May your craft keep shaping a stronger tomorrow."),
            listOf("उन सभी को अभियंता दिवस की शुभकामनाएँ जो कुशलता और लगन से निर्माण करते हैं।", "अभियंता दिवस पर हम उन सभी को नमन करते हैं जो विचारों को भरोसेमंद वास्तविकता में बदलते हैं।"),
            listOf("आपके कार्य में सटीकता, धैर्य और जुनून के लिए धन्यवाद।", "आपकी कला एक सशक्त कल का निर्माण करती रहे।"),
            tHi = "अभियंता दिवस की शुभकामनाएँ"),
        o("teachers_day", "Teachers' Day", "शिक्षक दिवस", Motif.STARS,
            listOf("Warm wishes on Teachers' Day to all who guide and inspire.", "On Teachers' Day, we thank those who shape minds and futures."),
            listOf("Your guidance builds the foundation for every success.", "Wishing you joy and respect today and always."),
            listOf("शिक्षक दिवस पर मार्गदर्शन और प्रेरणा देने वाले सभी को हार्दिक शुभकामनाएँ।", "शिक्षक दिवस पर हम उन सभी को धन्यवाद देते हैं जो मन और भविष्य को गढ़ते हैं।"),
            listOf("आपका मार्गदर्शन हर सफलता की नींव रखता है।", "आपको आज और सदा सम्मान और खुशियाँ मिलें।"),
            tHi = "शिक्षक दिवस की शुभकामनाएँ"),
        o("labour_day", "Labour Day", "श्रमिक दिवस", Motif.STARS,
            listOf("On Labour Day, we salute the hands that build our world.", "Happy Labour Day to the dedicated people behind every product we make."),
            listOf("Your effort, skill and commitment are the strength of our work.", "Wishing you health, respect and well-deserved rest."),
            listOf("श्रमिक दिवस पर हम उन हाथों को सलाम करते हैं जो हमारी दुनिया बनाते हैं।", "हमारे हर उत्पाद के पीछे समर्पित लोगों को श्रमिक दिवस की शुभकामनाएँ।"),
            listOf("आपकी मेहनत, कौशल और निष्ठा ही हमारे कार्य की शक्ति है।", "आपको अच्छा स्वास्थ्य, सम्मान और भरपूर आराम मिले।"),
            tHi = "श्रमिक दिवस की शुभकामनाएँ"),
        o("womens_day", "International Women's Day", "अंतरराष्ट्रीय महिला दिवस", Motif.STARS,
            listOf("Happy Women's Day to the women who lead, build and inspire.", "On Women's Day, we celebrate courage, talent and achievement."),
            listOf("Your strength makes every team and every family stronger.", "Wishing you respect, opportunity and joy every day."),
            listOf("नेतृत्व करने, रचने और प्रेरित करने वाली सभी महिलाओं को महिला दिवस की शुभकामनाएँ।", "महिला दिवस पर हम साहस, प्रतिभा और उपलब्धियों का उत्सव मनाते हैं।"),
            listOf("आपकी शक्ति हर टीम और हर परिवार को और मज़बूत बनाती है।", "आपको हर दिन सम्मान, अवसर और खुशियाँ मिलें।"),
            tEn = "Happy Women's Day", tHi = "महिला दिवस की शुभकामनाएँ"),
        o("holi", "Holi", "होली", Motif.SPLASH,
            listOf("Wishing you and your family a joyful and colourful Holi.", "May the colours of Holi fill your life with happiness and togetherness."),
            listOf("May this festival bring warmth, laughter and fresh beginnings.", "Warm wishes for a safe and joyful celebration."),
            listOf("आपको एवं आपके परिवार को होली की हार्दिक शुभकामनाएँ।", "होली के रंग आपके जीवन में खुशियाँ और अपनत्व भर दें।"),
            listOf("यह पर्व आपके जीवन में उमंग, हँसी और नई शुरुआत लेकर आए।", "सुरक्षित और आनंदमय उत्सव की शुभकामनाएँ।")),
        o("raksha_bandhan", "Raksha Bandhan", "रक्षाबंधन", Motif.STARS,
            listOf("Wishing you a joyful Raksha Bandhan filled with love and care.", "On Raksha Bandhan, may the bond of siblings grow stronger each year."),
            listOf("May your family be blessed with happiness and good health.", "Warm wishes to you and your loved ones."),
            listOf("आपको रक्षाबंधन की हार्दिक शुभकामनाएँ, यह दिन स्नेह और अपनत्व से भरा रहे।", "रक्षाबंधन पर भाई-बहन का पवित्र बंधन हर वर्ष और मज़बूत हो।"),
            listOf("आपके परिवार पर खुशियों और अच्छे स्वास्थ्य का आशीर्वाद बना रहे।", "आपको एवं आपके प्रियजनों को सादर शुभकामनाएँ।")),
        o("ganesh_chaturthi", "Ganesh Chaturthi", "गणेश चतुर्थी", Motif.STARS,
            listOf("Wishing you and your family a blessed Ganesh Chaturthi.", "May Lord Ganesha remove obstacles and bless your home with joy."),
            listOf("May wisdom, success and good fortune walk with you always.", "Ganpati Bappa Morya."),
            listOf("आपको एवं आपके परिवार को गणेश चतुर्थी की हार्दिक शुभकामनाएँ।", "भगवान गणेश आपकी हर बाधा दूर करें और आपके घर को खुशियों से भर दें।"),
            listOf("बुद्धि, सफलता और सौभाग्य सदा आपके साथ रहें।", "गणपति बप्पा मोरया।")),
        o("dussehra", "Dussehra", "दशहरा", Motif.STARS,
            listOf("Wishing you and your family a joyous Dussehra.", "May the victory of good over evil inspire strength and courage in your life."),
            listOf("May truth and righteousness guide every step ahead.", "Warm wishes for success and happiness."),
            listOf("आपको एवं आपके परिवार को दशहरा की हार्दिक शुभकामनाएँ।", "बुराई पर अच्छाई की जीत आपके जीवन में शक्ति और साहस भरे।"),
            listOf("सत्य और धर्म आपके हर कदम का मार्ग दिखाएँ।", "आपको सफलता और खुशियों की शुभकामनाएँ।")),
        o("janmashtami", "Janmashtami", "जन्माष्टमी", Motif.STARS,
            listOf("Wishing you and your family a blessed Janmashtami.", "May Lord Krishna's blessings bring joy, wisdom and peace to your home."),
            listOf("May devotion and harmony fill every day ahead.", "Warm wishes for good health and happiness."),
            listOf("आपको एवं आपके परिवार को जन्माष्टमी की हार्दिक शुभकामनाएँ।", "भगवान श्रीकृष्ण की कृपा से आपके घर में आनंद, ज्ञान और शांति बनी रहे।"),
            listOf("श्रद्धा और सद्भाव आपके हर दिन को मंगलमय बनाएँ।", "आपको अच्छे स्वास्थ्य और खुशियों की शुभकामनाएँ।")),
        o("navratri", "Navratri", "नवरात्रि", Motif.DIYA,
            listOf("Wishing you and your family a blessed and joyful Navratri.", "May the nine nights of Navratri bring you strength, devotion and happiness."),
            listOf("May Goddess Durga's blessings guide you with courage and wisdom.", "Warm wishes for health, success and peace."),
            listOf("आपको एवं आपके परिवार को नवरात्रि की हार्दिक शुभकामनाएँ।", "नवरात्रि की ये नौ रातें आपके जीवन में शक्ति, भक्ति और खुशियाँ लाएँ।"),
            listOf("माँ दुर्गा का आशीर्वाद आपको साहस और विवेक के साथ आगे बढ़ाए।", "आपको स्वास्थ्य, सफलता और शांति की शुभकामनाएँ।")),
        o("makar_sankranti", "Makar Sankranti", "मकर संक्रांति", Motif.STARS,
            listOf("Wishing you and your family a joyful Makar Sankranti.", "May the Sun's journey northward bring warmth, harvest and happiness to your home."),
            listOf("May this festival sweeten your days with prosperity and togetherness.", "Warm wishes for a bright and fruitful season."),
            listOf("आपको एवं आपके परिवार को मकर संक्रांति की हार्दिक शुभकामनाएँ।", "सूर्य का उत्तरायण आपके घर में ऊष्मा, समृद्धि और खुशियाँ लेकर आए।"),
            listOf("यह पर्व आपके जीवन में मिठास, समृद्धि और अपनापन भर दे।", "उज्ज्वल और फलदायी समय की शुभकामनाएँ।"))
    ).associateBy { it.key }

    private val thoughtsEn = listOf(
        "Great things are built through small, consistent efforts." to "Stay committed to progress, and success will follow.",
        "Quality is never an accident; it is the result of careful intent." to "Build every day with the same care as the first.",
        "Strong foundations make every journey steady." to "Invest in what lasts, and growth will follow.",
        "Every drop saved today secures a better tomorrow." to "Small acts of care can protect our greatest resource.",
        "Trust is built one reliable delivery at a time." to "Keep your promises, and the relationships will grow.",
        "Teamwork turns ordinary effort into extraordinary results." to "Together, we build more than any of us could alone.",
        "Reliability is the quiet promise behind every great product." to "Deliver it every day, and trust will follow.",
        "Discipline turns good intentions into lasting results." to "Show up with purpose, and progress will follow.",
        "Innovation begins when we question how things have always been done." to "Stay curious, and better ideas will find you.",
        "Clean water is the foundation of every healthy home." to "Protect it with care, and it will serve generations.",
        "Leadership is serving others well, not being served." to "Lead with humility, and teams will rise with you.",
        "Customers remember how reliably we showed up." to "Be dependable in small things, and big opportunities follow."
    )
    private val thoughtsHi = listOf(
        "छोटे-छोटे निरंतर प्रयास ही बड़ी सफलताओं की नींव रखते हैं।" to "अपने लक्ष्य के प्रति समर्पित रहें, सफलता अवश्य मिलेगी।",
        "गुणवत्ता संयोग नहीं, सोच-समझकर किए गए प्रयास का परिणाम होती है।" to "हर दिन उसी लगन से काम करें, जिस लगन से आपने शुरुआत की थी।",
        "मज़बूत नींव हर यात्रा को स्थिर बनाती है।" to "जो टिकाऊ है उसमें निवेश करें, उन्नति स्वयं आएगी।",
        "आज बचाई गई हर बूँद कल को बेहतर बनाती है।" to "छोटी-छोटी सावधानियाँ हमारे सबसे बड़े संसाधन की रक्षा करती हैं।",
        "भरोसा हर समय पर निभाए गए वादे से बनता है।" to "अपने वचन निभाएँ, रिश्ते स्वयं मज़बूत होंगे।",
        "एकजुट प्रयास साधारण मेहनत को असाधारण परिणाम में बदल देता है।" to "साथ मिलकर हम वह रच सकते हैं जो अकेले संभव नहीं।",
        "भरोसेमंद गुणवत्ता हर बेहतरीन उत्पाद का मौन वचन होती है।" to "इसे हर दिन निभाइए, विश्वास स्वयं बनेगा।",
        "अनुशासन अच्छे इरादों को स्थायी परिणामों में बदल देता है।" to "उद्देश्य के साथ आगे बढ़िए, प्रगति अवश्य होगी।",
        "नवाचार तब शुरू होता है जब हम पूछते हैं कि काम ऐसे ही क्यों होता आया है।" to "जिज्ञासु बने रहिए, बेहतर विचार स्वयं आपके पास आएँगे।",
        "स्वच्छ जल हर स्वस्थ घर की बुनियाद है।" to "इसे सँभालकर रखिए, यह पीढ़ियों तक काम आएगा।",
        "नेतृत्व का अर्थ दूसरों की सेवा करना है, सेवा करवाना नहीं।" to "विनम्रता से नेतृत्व कीजिए, आपकी टीम आपके साथ आगे बढ़ेगी।",
        "ग्राहक यह याद रखते हैं कि हम कितनी निष्ठा से उनके साथ खड़े रहे।" to "छोटी बातों में भरोसेमंद रहिए, बड़े अवसर स्वयं मिलेंगे।"
    )

    private val banned = Regex("kitec|guarantee|100%|best in india|cheapest|discount|offer", RegexOption.IGNORE_CASE)

    fun valid(l1: String, l2: String, lang: String): Boolean {
        for (s in listOf(l1, l2)) {
            if (s.isBlank() || s.contains('\n') || s.length > 120 || banned.containsMatchIn(s)) return false
            val dev = s.count { it in '\u0900'..'\u097F' }
            if (lang == "hi" && dev < s.count { it.isLetter() } * 0.6) return false
            if (lang == "en" && dev > 0) return false
        }
        return true
    }

    /** Returns (line1, line2, reused). reused=true means every combination was already used for this company. */
    fun compose(brand: String, occKey: String, lang: String, hist: List<Hist>, rnd: Random): Triple<String, String, Boolean>? {
        val occ = occasions[occKey]
        val all: List<Pair<String, String>> = if (occKey == "thought") (if (lang == "en") thoughtsEn else thoughtsHi)
        else if (occ == null) return null
        else if (lang == "en") occ.en1.flatMap { a -> occ.en2.map { b -> a to b } }
        else occ.hi1.flatMap { a -> occ.hi2.map { b -> a to b } }
        val ok = all.filter { valid(it.first, it.second, lang) }
        if (ok.isEmpty()) return null
        val used = hist.filter { it.brand == brand && it.occasion == occKey && it.lang == lang }.map { it.l1 to it.l2 }.toSet()
        val fresh = ok.filter { it !in used }
        val pick = (fresh.ifEmpty { ok }).let { it[rnd.nextInt(it.size)] }
        return Triple(pick.first, pick.second, fresh.isEmpty())
    }
}
