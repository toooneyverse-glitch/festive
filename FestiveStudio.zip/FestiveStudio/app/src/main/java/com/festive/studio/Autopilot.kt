package com.festive.studio

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.random.Random

/**
 * The on-device autopilot. tick() is idempotent: run it whenever the app opens or the background worker fires.
 * It only ever creates cards and alerts. It cannot send anything: sending is a separate, manual, owner-driven step.
 */
object Autopilot {
    private const val MAX_ATTEMPTS = 3
    fun today(): LocalDate = ZonedDateTime.now(IST).toLocalDate()

    suspend fun tick(ctx: Context, repo: Repo, today: LocalDate = today()): Int = withContext(Dispatchers.Default) {
        var created = 0
        for (e in repo.events.toList()) {
            val delta = ChronoUnit.DAYS.between(today, LocalDate.parse(e.date)).toInt()
            when (e.status) {
                "disputed", "unconfirmed" ->
                    if (delta in -1..14) repo.addAlert("date-${e.key}-${e.date}", "calendar",
                        "${e.nameEn}: please confirm the date in the Calendar tab (${e.note}). No cards are made until you do.")
                "verified", "fixed", "manual" -> {
                    if (Messages.occasions[e.key] == null) {
                        if (delta == 0) repo.addAlert("nopack-${e.key}-${e.date}", "needs_message_pack", "${e.nameEn} is today but has no greeting pack yet.")
                    } else for (b in Brands.all) {
                        val ex = repo.campaigns.find { it.brand == b.key && it.occasion == e.key && it.eventDate == e.date }
                        if (delta == 0) {
                            if (ex == null) { build(ctx, repo, b, e.key, e.date, null, 1, null); created++ }
                            else if (ex.status in setOf("qa_failed", "generation_failed") && ex.attempts < MAX_ATTEMPTS) { build(ctx, repo, b, e.key, e.date, ex, ex.attempts + 1, null); created++ }
                        } else if (delta in -3..-1 && ex == null) {
                            repo.addAlert("missed-${b.key}-${e.key}-${e.date}", "missed", "${e.nameEn} (${e.date}) passed with no ${b.name} greeting. Open the Cards tab to create a late one, or ignore.")
                        }
                    }
                }
            }
        }
        if (repo.thoughtEnabled) for (b in Brands.all) {
            val d = today.toString()
            val ex = repo.campaigns.find { it.brand == b.key && it.occasion == "thought" && it.eventDate == d }
            if (ex == null) { build(ctx, repo, b, "thought", d, null, 1, null); created++ }
            else if (ex.status in setOf("qa_failed", "generation_failed") && ex.attempts < MAX_ATTEMPTS) { build(ctx, repo, b, "thought", d, ex, ex.attempts + 1, null); created++ }
        }
        repo.lastRun = today.toString(); repo.save()
        created
    }

    /** Late/manual campaign for an occasion on its own date (used by "Create now" buttons). */
    suspend fun createNow(ctx: Context, repo: Repo, brandKey: String, occKey: String, date: String): Unit = withContext(Dispatchers.Default) {
        if (repo.campaigns.none { it.brand == brandKey && it.occasion == occKey && it.eventDate == date }) build(ctx, repo, Brands.get(brandKey), occKey, date, null, 1, null)
    }

    private fun build(ctx: Context, repo: Repo, brand: Brand, occKey: String, date: String, existing: Campaign?, attempt: Int, override: Map<String, Pair<String, String>>?): Campaign {
        val id = existing?.id ?: repo.newId()
        val occ = Messages.occasions[occKey]
        val images = mutableListOf<CardImage>(); var ok = true
        for (lang in listOf("en", "hi")) {
            val rnd = Random("$id-$attempt-$lang".hashCode().toLong())
            val txt: Pair<String, String>? = override?.get(lang) ?: Messages.compose(brand.key, occKey, lang, repo.history.toList(), rnd)?.let { it.first to it.second }
            if (txt == null) { ok = false; repo.addAlert("nomsg-$id-$lang", "generation_failed", "No valid greeting available for ${brand.name} $occKey ($lang)."); continue }
            val title = if (occ == null) (if (lang == "en") "Thought of the Day" else "आज का विचार") else (if (lang == "en") occ.titleEn else occ.titleHi)
            val out = File(repo.cardsDir, "${brand.key}_${occKey}_${date}_${lang}_${id}_$attempt.jpg")
            val r = try { CardRenderer.render(ctx, brand, occ, lang, "$id-$attempt", txt.first, txt.second, title, out) } catch (e: Exception) { RenderResult(false, "error: ${e.javaClass.simpleName}") }
            if (!r.ok) ok = false
            if (out.exists()) images.add(CardImage(lang, out.absolutePath, txt.first, txt.second, if (override != null) "edited by owner" else "on-device generator", r.qa))
            repo.history.add(Hist(brand.key, occKey, lang, txt.first, txt.second))
        }
        existing?.images?.forEach { old -> if (images.none { it.file == old.file }) File(old.file).delete() }
        val status = if (images.size == 2 && ok) "awaiting_approval" else if (images.isNotEmpty()) "qa_failed" else "generation_failed"
        val c = Campaign(id, brand.key, occKey, date, status, attempt, images)
        repo.putCampaign(c)
        repo.audit("autopilot", if (override != null) "edited" else "generated", "campaign=$id ${brand.key} $occKey status=$status")
        if (status == "awaiting_approval") repo.addAlert("review-$id-$attempt", "review", "${brand.name}: ${occ?.nameEn ?: "Thought of the Day"} cards are ready for your review.")
        return c
    }

    suspend fun regenerate(ctx: Context, repo: Repo, cid: Int) = withContext(Dispatchers.Default) {
        val c = repo.campaigns.find { it.id == cid } ?: return@withContext
        repo.audit(repo.ownerName, "regenerate", "campaign=$cid")
        build(ctx, repo, Brands.get(c.brand), c.occasion, c.eventDate, c, c.attempts + 1, null)
        Unit
    }

    /** Re-render with the owner's own wording (same design). Previous approval is void. */
    suspend fun editText(ctx: Context, repo: Repo, cid: Int, en: Pair<String, String>, hi: Pair<String, String>): Boolean = withContext(Dispatchers.Default) {
        val c = repo.campaigns.find { it.id == cid } ?: return@withContext false
        if (!Messages.valid(en.first, en.second, "en") || !Messages.valid(hi.first, hi.second, "hi")) return@withContext false
        repo.audit(repo.ownerName, "edit_text", "campaign=$cid")
        build(ctx, repo, Brands.get(c.brand), c.occasion, c.eventDate, c, c.attempts, mapOf("en" to en, "hi" to hi))
        true
    }

    fun approve(repo: Repo, cid: Int): Boolean {
        val c = repo.campaigns.find { it.id == cid } ?: return false
        if (c.status != "awaiting_approval") return false
        repo.putCampaign(c.copy(status = "approved", approvedBy = repo.ownerName, approvedAt = repo.now()))
        repo.audit(repo.ownerName, "approve", "campaign=$cid")
        return true
    }

    fun eligibleContacts(repo: Repo, c: Campaign): List<Contact> =
        repo.contacts.filter { it.brand == c.brand && it.consent && !it.optedOut }
}
