package com.festive.studio

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.File

/** Manual sharing only. WhatsApp always opens with the card ready and the owner taps Send. Nothing is sent automatically. */
object Sharing {
    private fun uri(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    fun share(ctx: Context, f: File, caption: String = "") {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uri(ctx, f))
            if (caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, caption)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Share card").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun whatsappPackage(ctx: Context): String? {
        for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try { ctx.packageManager.getPackageInfo(p, 0); return p } catch (e: Exception) { }
        }
        return null
    }

    /** Opens WhatsApp for one contact with the card attached. Uses WhatsApp's 'jid' extra (not an official API; may stop working). */
    fun sendToContact(ctx: Context, f: File, phoneDigits: String, caption: String): Boolean {
        val pkg = whatsappPackage(ctx) ?: return false
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"; setPackage(pkg)
            putExtra(Intent.EXTRA_STREAM, uri(ctx, f)); putExtra("jid", "$phoneDigits@s.whatsapp.net")
            if (caption.isNotBlank()) putExtra(Intent.EXTRA_TEXT, caption)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try { ctx.startActivity(i); true } catch (e: ActivityNotFoundException) { false }
    }

    fun saveToGallery(ctx: Context, f: File): Boolean = if (Build.VERSION.SDK_INT >= 29) save29(ctx, f) else false

    @RequiresApi(29)
    private fun save29(ctx: Context, f: File): Boolean {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, f.name); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FestiveStudio")
        }
        val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(u)?.use { out -> f.inputStream().use { it.copyTo(out) } }
        return true
    }
}

data class ImportResult(val added: Int, val duplicates: Int, val invalid: List<String>)

object ContactImport {
    fun normalize(raw: String): String? {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        return when {
            d.length == 10 && d[0] in '6'..'9' -> "91$d"
            d.length == 11 && d[0] == '0' && d[1] in '6'..'9' -> "91" + d.drop(1)
            d.length == 12 && d.startsWith("91") && d[2] in '6'..'9' -> d
            else -> null
        }
    }
    fun pretty(p: String) = if (p.length == 12) "+91 ${p.substring(2, 7)} ${p.substring(7)}" else "+$p"

    private fun splitCsv(line: String): List<String> {
        val out = mutableListOf<String>(); val sb = StringBuilder(); var q = false
        for (ch in line) { when { ch == '"' -> q = !q; ch == ',' && !q -> { out.add(sb.toString().trim()); sb.clear() }; else -> sb.append(ch) } }
        out.add(sb.toString().trim()); return out
    }

    /** CSV columns (header optional): name, phone, brand (nector/carewell/both), language (en/hi), consent (yes/no). Consent defaults to NO. */
    fun import(text: String, repo: Repo): ImportResult {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return ImportResult(0, 0, emptyList())
        val first = splitCsv(lines[0]).map { it.lowercase() }
        val hasHeader = first.any { it in setOf("name", "phone", "mobile", "whatsapp", "brand", "consent") }
        fun idx(vararg names: String, def: Int) = if (hasHeader) first.indexOfFirst { it in names } else def
        val iN = idx("name", def = 0); val iP = idx("phone", "mobile", "whatsapp", "number", def = 1)
        val iB = idx("brand", "company", def = 2); val iL = idx("language", "lang", def = 3); val iC = idx("consent", "optin", "opt-in", def = 4)
        var added = 0; var dup = 0; val bad = mutableListOf<String>()
        for (ln in lines.drop(if (hasHeader) 1 else 0)) {
            val c = splitCsv(ln); fun col(i: Int) = if (i >= 0 && i < c.size) c[i] else ""
            val phone = normalize(col(iP))
            if (phone == null) { bad.add(ln.take(40)); continue }
            val b = col(iB).lowercase()
            val brands = when { b.contains("both") || b.isEmpty() -> listOf("nector", "carewell"); b.contains("care") -> listOf("carewell"); else -> listOf("nector") }
            val lang = if (col(iL).lowercase().startsWith("h")) "hi" else "en"
            val consent = col(iC).lowercase() in setOf("yes", "y", "true", "1")
            for (br in brands) {
                if (repo.contacts.any { it.phone == phone && it.brand == br }) { dup++; continue }
                repo.contacts.add(Contact(col(iN).ifBlank { pretty(phone) }, phone, br, lang, consent, false)); added++
            }
        }
        repo.save(); repo.audit(repo.ownerName, "import_contacts", "added=$added dup=$dup invalid=${bad.size}")
        return ImportResult(added, dup, bad)
    }
}
