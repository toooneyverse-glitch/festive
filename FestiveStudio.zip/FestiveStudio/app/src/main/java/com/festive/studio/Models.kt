package com.festive.studio

import android.graphics.Color
import java.time.ZoneId

val IST: ZoneId = ZoneId.of("Asia/Kolkata")

data class Event(
    val key: String, val date: String, val nameEn: String, val nameHi: String,
    val status: String,            // verified | fixed | manual | disputed | unconfirmed
    val source: String, val note: String = ""
)

data class CardImage(val lang: String, val file: String, val l1: String, val l2: String, val source: String, val qa: String)

data class Campaign(
    val id: Int, val brand: String, val occasion: String, val eventDate: String,
    val status: String,            // awaiting_approval | approved | qa_failed | generation_failed
    val attempts: Int, val images: List<CardImage>,
    val approvedBy: String = "", val approvedAt: String = ""
)

data class Contact(val name: String, val phone: String, val brand: String, val lang: String, val consent: Boolean, val optedOut: Boolean)
data class Alert(val key: String, val kind: String, val message: String, val at: String, val dismissed: Boolean = false)
data class Hist(val brand: String, val occasion: String, val lang: String, val l1: String, val l2: String)

data class Brand(val key: String, val name: String, val logoAsset: String, val plate: Int?, val footer: List<String>)

object Brands {
    // Footer lines contain ONLY contact details published on the companies' own websites.
    val all = listOf(
        Brand("nector", "Nector Industries", "nector_logo.png", null,
            listOf("nectorindia.com", "info@nectorindia.com", "+91 98681 87578")),
        Brand("carewell", "Carewell Pipes", "carewell_logo.png", Color.rgb(58, 63, 166),
            listOf("carewellpipes.com"))
    )
    fun get(key: String): Brand = all.first { it.key == key }
}
