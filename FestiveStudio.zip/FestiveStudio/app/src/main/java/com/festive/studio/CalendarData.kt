package com.festive.studio

/**
 * Built-in calendar. Only two kinds of dates are trusted automatically:
 *  - fixed Gregorian dates (national / international days), computed for any year
 *  - lunar festival dates that were cross-checked against several published calendars
 * Everything else (disputed or unknown) needs the owner to confirm or enter the date in the Calendar tab.
 */
object CalendarData {
    private const val SRC = "Business Standard; Business Today; Time Out (citing Drik Panchang); Almanac; Hindutone - checked 8 Nov 2026"

    fun verified(): List<Event> = listOf(
        Event("dhanteras", "2026-11-06", "Dhanteras", "धनतेरस", "verified", SRC, "Friday. Sources agree."),
        Event("diwali", "2026-11-08", "Diwali", "दीपावली", "verified", SRC, "Lakshmi Puja, Sunday. Sources agree."),
        Event("govardhan_puja", "2026-11-09", "Govardhan Puja", "गोवर्धन पूजा", "disputed", "Business Standard; Business Today", "Sources give 9 Nov or 10 Nov"),
        Event("bhai_dooj", "2026-11-10", "Bhai Dooj", "भाई दूज", "disputed", "Business Standard; Time Out", "Sources give 10 Nov or 11 Nov"),
        Event("chhath_puja", "2026-11-15", "Chhath Puja", "छठ पूजा", "disputed", "Business Standard; Hindutone", "Sources give 15 Nov or 18 Nov")
    )

    private data class Fixed(val key: String, val md: String, val en: String, val hi: String)
    private val fixed = listOf(
        Fixed("new_year", "01-01", "New Year", "नववर्ष"),
        Fixed("republic_day", "01-26", "Republic Day", "गणतंत्र दिवस"),
        Fixed("womens_day", "03-08", "International Women's Day", "अंतरराष्ट्रीय महिला दिवस"),
        Fixed("world_water_day", "03-22", "World Water Day", "विश्व जल दिवस"),
        Fixed("new_financial_year", "04-01", "New Financial Year", "नया वित्तीय वर्ष"),
        Fixed("labour_day", "05-01", "Labour Day", "श्रमिक दिवस"),
        Fixed("world_environment_day", "06-05", "World Environment Day", "विश्व पर्यावरण दिवस"),
        Fixed("independence_day", "08-15", "Independence Day", "स्वतंत्रता दिवस"),
        Fixed("teachers_day", "09-05", "Teachers' Day", "शिक्षक दिवस"),
        Fixed("engineers_day", "09-15", "Engineers' Day", "अभियंता दिवस"),
        Fixed("gandhi_jayanti", "10-02", "Gandhi Jayanti", "गांधी जयंती")
    )

    fun fixedFor(year: Int): List<Event> =
        fixed.map { Event(it.key, "$year-${it.md}", it.en, it.hi, "fixed", "Fixed Gregorian date") }
}
