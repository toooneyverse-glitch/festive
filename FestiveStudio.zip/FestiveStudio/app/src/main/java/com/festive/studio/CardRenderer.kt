package com.festive.studio

import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream
import kotlin.math.*
import kotlin.random.Random

const val W = 1080
const val H = 1350

data class Pal(val n: String, val a: Int, val b: Int, val gold: Int, val title: Int, val body: Int, val dark: Boolean)
data class RenderResult(val ok: Boolean, val qa: String)

/** Deterministic on-device compositor: procedural art + original logo overlay + real text (HarfBuzz shaping via Android). */
object CardRenderer {
    private fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private val palettes = listOf(
        Pal("ivory-ruby", rgb(253, 243, 224), rgb(244, 221, 186), rgb(201, 143, 40), rgb(158, 24, 36), rgb(90, 45, 40), false),
        Pal("plum", rgb(74, 18, 96), rgb(150, 28, 118), rgb(244, 200, 96), rgb(255, 226, 150), rgb(255, 240, 230), true),
        Pal("midnight", rgb(12, 24, 64), rgb(40, 52, 120), rgb(250, 205, 100), rgb(255, 222, 140), rgb(238, 240, 255), true),
        Pal("saffron", rgb(255, 190, 90), rgb(232, 110, 40), rgb(255, 236, 170), rgb(110, 20, 20), rgb(70, 25, 20), false),
        Pal("emerald", rgb(6, 60, 56), rgb(12, 110, 92), rgb(246, 206, 110), rgb(255, 230, 160), rgb(235, 250, 244), true),
        Pal("maroon", rgb(92, 10, 28), rgb(150, 30, 40), rgb(246, 196, 90), rgb(255, 224, 150), rgb(255, 238, 226), true)
    )
    private val tri = Pal("tricolour", rgb(253, 250, 240), rgb(246, 236, 214), rgb(255, 153, 51), rgb(19, 45, 130), rgb(40, 40, 60), false)
    private val aqua = Pal("aqua", rgb(220, 244, 252), rgb(150, 208, 238), rgb(0, 119, 182), rgb(0, 60, 110), rgb(20, 50, 80), false)
    private val forest = Pal("forest", rgb(6, 60, 40), rgb(20, 110, 70), rgb(200, 230, 120), rgb(235, 250, 200), rgb(235, 250, 240), true)

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private fun stroke(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.STROKE; strokeWidth = w }

    // ---------- background art ----------
    private fun glow(c: Canvas, cx: Float, cy: Float, r: Float, color: Int, alpha: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(cx, cy, r, intArrayOf(al(color, alpha), al(color, 0)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
    }

    private fun background(c: Canvas, pal: Pal, kind: String, rnd: Random, cx: Float, cy: Float) {
        val g = pal.gold
        when (kind) {
            "rings" -> {
                for (i in 1..8) c.drawCircle(cx, cy, i * 120f, stroke(al(g, 38), 3f))
                for (k in 0 until 24) {
                    val a = k * PI / 12
                    c.drawLine((cx + 300 * cos(a)).toFloat(), (cy + 300 * sin(a)).toFloat(), (cx + 520 * cos(a)).toFloat(), (cy + 520 * sin(a)).toFloat(), stroke(al(g, 40), 3f))
                }
            }
            "bokeh" -> repeat(45) { c.drawCircle(rnd.nextInt(W).toFloat(), rnd.nextInt(H).toFloat(), (14 + rnd.nextInt(46)).toFloat(), fill(al(g, 14 + rnd.nextInt(28)))) }
            "rays" -> {
                val n = listOf(18, 24, 30)[rnd.nextInt(3)]
                val p = fill(al(g, 22))
                for (k in 0 until n) {
                    val a0 = 2 * PI * k / n; val a1 = a0 + PI / n; val R = 2000.0
                    val path = Path()
                    path.moveTo(cx, cy)
                    path.lineTo((cx + R * cos(a0)).toFloat(), (cy + R * sin(a0)).toFloat())
                    path.lineTo((cx + R * cos(a1)).toFloat(), (cy + R * sin(a1)).toFloat())
                    path.close(); c.drawPath(path, p)
                }
            }
            else -> {
                val step = listOf(54, 66, 80)[rnd.nextInt(3)]
                val p = fill(al(g, 40))
                var x = 0
                while (x < W) { var y = 0; while (y < H) { c.drawCircle(x.toFloat(), y.toFloat(), 4f, p); y += step }; x += step }
            }
        }
    }

    // ---------- motifs ----------
    private fun diya(c: Canvas, cx: Float, cy: Float, s: Float, pal: Pal) {
        val bowl = if (pal.dark) rgb(214, 120, 40) else rgb(176, 62, 34)
        glow(c, cx, cy - s * .35f, s * .75f, rgb(255, 190, 80), 120)
        val oval = RectF(cx - s / 2, cy - s * .30f, cx + s / 2, cy + s * .30f)
        c.drawArc(oval, 0f, 180f, true, fill(bowl))
        c.drawArc(oval, 0f, 180f, true, stroke(pal.gold, max(2f, s / 40)))
        c.drawOval(RectF(cx - s * .5f, cy - s * .08f, cx + s * .5f, cy + s * .08f), fill(Color.argb(255, min(255, Color.red(bowl) + 30), min(255, Color.green(bowl) + 30), min(255, Color.blue(bowl) + 30))))
        c.drawArc(RectF(cx - s * .30f, cy + s * .02f, cx + s * .30f, cy + s * .26f), 20f, 140f, false, stroke(pal.gold, max(2f, s / 45)))
        flame(c, cx, cy - s * .06f, s * .62f, s * .20f, rgb(255, 176, 40))
        flame(c, cx, cy - s * .06f, s * .38f, s * .10f, rgb(255, 244, 190))
    }

    private fun flame(c: Canvas, x: Float, baseY: Float, h: Float, w: Float, color: Int) {
        val p = Path()
        p.moveTo(x, baseY - h)
        p.quadTo(x + w * 1.5f, baseY - h * .35f, x, baseY)
        p.quadTo(x - w * 1.5f, baseY - h * .35f, x, baseY - h)
        p.close(); c.drawPath(p, fill(color))
    }

    private fun flag(c: Canvas, cx: Float, cy: Float) {
        val w = 560f; val h = 360f; val l = cx - w / 2; val t = cy - h / 2
        val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(24f, 0f, 10f, Color.argb(90, 0, 0, 0)) }
        c.drawRoundRect(RectF(l, t, l + w, t + h), 18f, 18f, sh)
        c.save()
        val clip = Path(); clip.addRoundRect(RectF(l, t, l + w, t + h), 18f, 18f, Path.Direction.CW); c.clipPath(clip)
        c.drawRect(l, t, l + w, t + h / 3, fill(rgb(255, 153, 51)))
        c.drawRect(l, t + h / 3, l + w, t + 2 * h / 3, fill(Color.WHITE))
        c.drawRect(l, t + 2 * h / 3, l + w, t + h, fill(rgb(19, 136, 8)))
        c.restore()
        val navy = rgb(0, 0, 128); val r = 56f
        c.drawCircle(cx, cy, r, stroke(navy, 5f))
        for (k in 0 until 24) { val a = k * PI / 12; c.drawLine(cx, cy, (cx + r * cos(a)).toFloat(), (cy + r * sin(a)).toFloat(), stroke(navy, 2.5f)) }
        c.drawCircle(cx, cy, 9f, fill(navy))
    }

    private fun drop(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val p = Path()
        p.moveTo(x, y - r * 1.8f)
        p.cubicTo(x + r * .5f, y - r * .9f, x + r, y - r * .4f, x + r, y)
        p.arcTo(RectF(x - r, y - r, x + r, y + r), 0f, 180f)
        p.cubicTo(x - r, y - r * .4f, x - r * .5f, y - r * .9f, x, y - r * 1.8f)
        p.close(); c.drawPath(p, fill(color))
        c.drawCircle(x - r * .35f, y + r * .1f, r * .18f, fill(Color.argb(150, 255, 255, 255)))
    }

    private fun leaf(c: Canvas, x: Float, y: Float, len: Float, angle: Float, color: Int) {
        c.save(); c.translate(x, y); c.rotate(angle)
        val p = Path(); p.moveTo(0f, 0f); p.quadTo(len * .5f, -len * .38f, len, 0f); p.quadTo(len * .5f, len * .38f, 0f, 0f); p.close()
        c.drawPath(p, fill(color)); c.drawLine(0f, 0f, len * .95f, 0f, stroke(al(Color.WHITE, 90), 3f)); c.restore()
    }

    private fun star(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val p = Path()
        for (k in 0 until 8) {
            val a = k * PI / 4 - PI / 2; val rr = if (k % 2 == 0) r else r * .28f
            val px = (x + rr * cos(a)).toFloat(); val py = (y + rr * sin(a)).toFloat()
            if (k == 0) p.moveTo(px, py) else p.lineTo(px, py)
        }
        p.close(); c.drawPath(p, fill(color))
    }

    private fun motif(c: Canvas, m: Motif, cx: Float, cy: Float, pal: Pal, rnd: Random) {
        when (m) {
            Motif.DIYA -> when (rnd.nextInt(3)) {
                0 -> diya(c, cx, cy, 300f, pal)
                1 -> { diya(c, cx - 260, cy + 40, 220f, pal); diya(c, cx + 260, cy + 40, 220f, pal); diya(c, cx, cy - 10, 280f, pal) }
                else -> { val n = if (rnd.nextBoolean()) 3 else 5; for (i in 0 until n) { val d = i - (n - 1) / 2f; diya(c, cx + d * 190, cy + abs(d) * 24, 160f, pal) } }
            }
            Motif.TRICOLOUR -> flag(c, cx, cy)
            Motif.DROPS -> repeat(9) { drop(c, cx + rnd.nextInt(-380, 380), cy + rnd.nextInt(-90, 150), (26 + rnd.nextInt(44)).toFloat(), al(pal.gold, 150 + rnd.nextInt(90))) }
            Motif.LEAVES -> repeat(11) { leaf(c, cx + rnd.nextInt(-360, 360), cy + rnd.nextInt(-80, 160), (90 + rnd.nextInt(110)).toFloat(), rnd.nextInt(-80, 80).toFloat() - 45, al(pal.gold, 170 + rnd.nextInt(70))) }
            Motif.SPLASH -> {
                val cols = listOf(rgb(255, 87, 34), rgb(233, 30, 99), rgb(0, 188, 212), rgb(76, 175, 80), rgb(255, 235, 59), rgb(156, 39, 176))
                repeat(22) { c.drawCircle(cx + rnd.nextInt(-400, 400), cy + rnd.nextInt(-110, 170), (40 + rnd.nextInt(70)).toFloat(), fill(al(cols[rnd.nextInt(cols.size)], 175))) }
            }
            Motif.STARS -> { star(c, cx, cy + 10, 130f, pal.gold); repeat(14) { star(c, cx + rnd.nextInt(-400, 400), cy + rnd.nextInt(-120, 170), (14 + rnd.nextInt(34)).toFloat(), al(pal.gold, 170)) } }
            Motif.NONE -> {}
        }
    }

    // ---------- logo ----------
    private fun trim(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        var l = w; var t = h; var r = -1; var bt = -1
        for (y in 0 until h) for (x in 0 until w) if ((px[y * w + x] ushr 24) > 8) { if (x < l) l = x; if (x > r) r = x; if (y < t) t = y; if (y > bt) bt = y }
        return if (r < 0) b else Bitmap.createBitmap(b, l, t, r - l + 1, bt - t + 1)
    }

    // ---------- main ----------
    fun render(ctx: Context, brand: Brand, occ: Occ?, lang: String, seed: String, l1: String, l2: String, title: String, out: File): RenderResult {
        val rnd = Random((seed + brand.key + lang).hashCode().toLong())
        val m = occ?.motif ?: Motif.NONE
        val pal = when (m) { Motif.TRICOLOUR -> tri; Motif.DROPS -> aqua; Motif.LEAVES -> forest; else -> palettes[rnd.nextInt(palettes.size)] }
        val layout = if (occ == null) "framed" else listOf("top", "bottom", "framed")[rnd.nextInt(3)]
        val bgKind = listOf("rings", "bokeh", "rays", "dots")[rnd.nextInt(4)]
        val mcy = if (layout == "bottom") 1010f else 390f

        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); val c = Canvas(bmp)
        val gp = Paint().apply { shader = LinearGradient(0f, 0f, 0f, H.toFloat(), pal.a, pal.b, Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), gp)
        background(c, pal, bgKind, rnd, W / 2f, mcy)
        motif(c, m, W / 2f, mcy, pal, rnd)
        if (layout == "framed") { c.drawRect(34f, 34f, W - 34f, H - 34f, stroke(pal.gold, 4f)); c.drawRect(50f, 50f, W - 50f, H - 50f, stroke(al(pal.gold, 160), 1.5f)) }

        // logo (original file, never redrawn)
        var logoBox = RectF(); var logoScale = 1f
        try {
            val raw = ctx.assets.open(brand.logoAsset).use { BitmapFactory.decodeStream(it) }
            val tr = trim(raw); val tw = if (brand.key == "nector") 330 else 440
            logoScale = tw.toFloat() / tr.width
            val lg = Bitmap.createScaledBitmap(tr, tw, (tr.height * tw / tr.width.toFloat()).roundToInt(), true)
            val pad = if (brand.plate != null) 16 else 0
            val lw = lg.width + 2 * pad; val lh = lg.height + 2 * pad
            val lx = (W - lw) / 2f; val ly = if (layout == "bottom") 100f else 90f
            logoBox = RectF(lx, ly, lx + lw, ly + lh)
            if (brand.plate != null) c.drawRoundRect(logoBox, 14f, 14f, fill(brand.plate))
            else c.drawRect(lx - 3, ly - 3, lx + lw + 3, ly + lh + 3, stroke(pal.gold, 3f))
            c.drawBitmap(lg, lx + pad, ly + pad, Paint(Paint.FILTER_BITMAP_FLAG))
        } catch (e: Exception) { return RenderResult(false, "logo_missing") }

        // text layouts
        val hi = lang == "hi"
        val serif = Typeface.create(Typeface.SERIF, Typeface.BOLD); val serifR = Typeface.SERIF
        val sans = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD); val sansR = Typeface.SANS_SERIF
        fun tf(bold: Boolean) = if (hi) (if (bold) sans else sansR) else (if (bold) serif else serifR)
        fun mk(text: String, size: Float, color: Int, bold: Boolean, width: Int): StaticLayout {
            val t = TextPaint(Paint.ANTI_ALIAS_FLAG); t.textSize = size; t.color = color; t.typeface = tf(bold)
            val b = StaticLayout.Builder.obtain(text, 0, text.length, t, width).setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, if (hi) 1.25f else 1.15f).setIncludePad(true)
            if (Build.VERSION.SDK_INT >= 28) b.setUseLineSpacingFromFallbacks(true)
            return b.build()
        }
        val MARG = 70; val tw = W - 2 * MARG
        var ts = if (hi) 92f else 104f
        var tl = mk(title, ts, pal.title, true, tw)
        while (tl.lineCount > 1 && ts > 60f) { ts -= 4f; tl = mk(title, ts, pal.title, true, tw) }
        val bs = if (hi) 44f else 40f
        val b1 = mk(l1, bs, pal.body, false, tw - 40); val b2 = mk(l2, bs, pal.body, false, tw - 40)
        val sigText = if (occ == null) "— ${brand.name}" else if (hi) "सादर शुभकामनाएँ, ${brand.name}" else "Warm wishes from ${brand.name}"
        val sg = mk(sigText, if (hi) 42f else 38f, if (pal.dark) pal.gold else pal.title, true, tw)

        var y = if (layout == "bottom") logoBox.bottom + 90f else if (occ == null) 470f else 610f
        val boxes = mutableListOf<RectF>()
        data class Item(val l: StaticLayout, val x: Float, val y: Float, val w: Float)
        val items = mutableListOf<Item>()
        fun place(l: StaticLayout, width: Int) {
            var mw = 0f; for (i in 0 until l.lineCount) mw = max(mw, l.getLineWidth(i))
            val x = (W - width) / 2f
            items.add(Item(l, x, y, width.toFloat())); boxes.add(RectF((W - mw) / 2f, y, (W + mw) / 2f, y + l.height)); y += l.height
        }
        place(tl, tw); val divY = y + 18f; y += 18f + 3f + 34f
        place(b1, tw - 40); y += 16f; place(b2, tw - 40); y += 26f; place(sg, tw)

        val panel = RectF(MARG - 10f, boxes.minOf { it.top } - 38f, W - MARG + 10f, boxes.maxOf { it.bottom } + 38f)
        val pf = fill(if (pal.dark) Color.argb(120, 10, 6, 24) else Color.argb(150, 255, 250, 238))
        c.drawRoundRect(panel, 36f, 36f, pf); c.drawRoundRect(panel, 36f, 36f, stroke(al(pal.gold, 150), 2f))
        c.drawLine(W / 2f - 120, divY, W / 2f + 120, divY, stroke(pal.gold, 3f))
        for (item in items) { c.save(); c.translate(item.x, item.y); item.l.draw(c); c.restore() }

        // footer: verified contact details only
        c.drawRect(0f, H - 140f, W.toFloat(), H.toFloat(), fill(if (pal.dark) Color.argb(90, 0, 0, 0) else al(pal.gold, 90)))
        val fp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 30f; color = pal.body; typeface = Typeface.SERIF }
        val foot = brand.footer.joinToString("  |  ")
        while (fp.measureText(foot) > W - 140 && fp.textSize > 18f) fp.textSize -= 1f
        val fw = fp.measureText(foot); c.drawText(foot, (W - fw) / 2f, H - 70f, fp)
        val footBox = RectF((W - fw) / 2f, H - 100f, (W + fw) / 2f, H - 66f)

        // ---- QA ----
        val inside = (boxes + logoBox + footBox).all { it.left >= 40 && it.right <= W - 40 && it.top >= 40 && it.bottom <= H - 40 }
        val glyphPaint = Paint().apply { typeface = tf(true) }
        val glyphs = (title + l1 + l2 + sigText).filter { !it.isWhitespace() && it != '\u200D' && it != '\u200C' }.all { glyphPaint.hasGlyph(it.toString()) }
        val footerClear = panel.bottom <= H - 150
        val sharp = logoScale <= 1.8f
        val ok = inside && glyphs && footerClear
        val qa = "size=ok;margins=${if (inside) "ok" else "FAIL"};glyphs=${if (glyphs) "ok" else "FAIL"};footer=${if (footerClear) "ok" else "FAIL"};logoScale=${"%.2f".format(logoScale)}${if (sharp) "" else " (soft)"}"
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 96, it) }
        bmp.recycle()
        return RenderResult(ok, qa)
    }
}
