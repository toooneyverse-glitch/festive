package com.festive.studio

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object Notifier {
    fun notify(ctx: Context, title: String, text: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("review", "Card review", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(ctx, "review").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text).setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(1001, n)
        } catch (e: Exception) { /* notification permission not granted: the in-app alerts still show */ }
    }
}

/** Runs every ~15 minutes (Android's minimum). Acts once per day, after the owner's chosen time; catches up if the phone was off. */
class DailyWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val repo = Repo.get(applicationContext)
        val now = ZonedDateTime.now(IST)
        val today = now.toLocalDate().toString()
        val due = now.hour > repo.notifyHour || (now.hour == repo.notifyHour && now.minute >= repo.notifyMinute)
        if (!due || repo.lastRun == today) return Result.success()
        val n = Autopilot.tick(applicationContext, repo)
        if (n > 0) Notifier.notify(applicationContext, "Greeting cards ready", "$n new campaign(s) are waiting for your approval.")
        return Result.success()
    }
}

object Scheduler {
    fun ensure(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<DailyWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("festive-daily", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}
