package com.festive.studio

import android.Manifest
import android.content.Context
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Scheduler.ensure(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF8E1B2C), secondary = Color(0xFFC98F28), tertiary = Color(0xFF3A3FA6))) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private val prettyDate: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy")
private fun fmt(d: String) = try { LocalDate.parse(d).format(prettyDate) } catch (e: Exception) { d }
private fun brandName(k: String) = Brands.get(k).name
private fun occName(k: String) = if (k == "thought") "Thought of the Day" else (Messages.occasions[k]?.nameEn ?: k)
private fun statusLabel(s: String) = when (s) {
    "awaiting_approval" -> "Awaiting your approval"; "approved" -> "Approved"; "qa_failed" -> "Quality check failed"
    "generation_failed" -> "Could not generate"; else -> s
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val repo = remember { Repo.get(ctx) }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    fun runTick() { scope.launch { busy = true; Autopilot.tick(ctx, repo); busy = false } }
    LaunchedEffect(Unit) { runTick() }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("Home" to "🏠", "Cards" to "🖼", "Calendar" to "📅", "Contacts" to "👥", "Settings" to "⚙").forEachIndexed { i, (l, e) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e) }, label = { Text(l, fontSize = 11.sp) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(repo, busy) { runTick() }
                1 -> CardsScreen(repo)
                2 -> CalendarScreen(repo)
                3 -> ContactsScreen(repo)
                else -> SettingsScreen(repo)
            }
        }
    }
}

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(repo: Repo, busy: Boolean, onGenerate: () -> Unit) {
    val today = Autopilot.today()
    val todays = repo.events.filter { it.date == today.toString() }
    val next = repo.events.filter { LocalDate.parse(it.date).isAfter(today) && it.status != "disputed" }.minByOrNull { it.date }
    val pending = repo.campaigns.count { it.status == "awaiting_approval" }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Festive Studio", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(today.format(prettyDate), color = Color.Gray)
        }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("Today", fontWeight = FontWeight.Bold)
                if (todays.isEmpty()) Text("No festival or occasion today.") else todays.forEach { Text("${it.nameEn} / ${it.nameHi}  (${it.status})") }
                Spacer(Modifier.height(6.dp))
                Text("Next occasion: " + (next?.let { "${it.nameEn} - ${fmt(it.date)}" } ?: "none scheduled"))
                Text("Waiting for your approval: $pending", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onGenerate, enabled = !busy) { Text(if (busy) "Working..." else "Check today and create cards") }
            } }
        }
        val live = repo.alerts.filter { !it.dismissed }.reversed()
        item { Text("Alerts (${live.size})", fontWeight = FontWeight.Bold) }
        items(live) { a ->
            Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(a.message, Modifier.weight(1f), fontSize = 14.sp)
                TextButton(onClick = { repo.dismissAlert(a.key) }) { Text("Dismiss") }
            } }
        }
    }
}

// ------------------------------------------------------------------ CARDS
@Composable
fun CardsScreen(repo: Repo) {
    val list = repo.campaigns.sortedWith(compareByDescending<Campaign> { it.eventDate }.thenByDescending { it.id })
    if (list.isEmpty()) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No cards yet. Open Home and tap \"Check today and create cards\".") }; return }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(list) { CampaignCard(repo, it) }
    }
}

@Composable
fun Preview(path: String, modifier: Modifier) {
    val bm = remember(path) { BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 3 })?.asImageBitmap() }
    if (bm != null) Image(bm, null, modifier, contentScale = ContentScale.Fit) else Box(modifier) { Text("(image missing)") }
}

@Composable
fun CampaignCard(repo: Repo, c: Campaign) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf(false) }; var edit by remember { mutableStateOf(false) }; var send by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
        Text("${brandName(c.brand)} - ${occName(c.occasion)}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text("${fmt(c.eventDate)}  |  ${statusLabel(c.status)}" + if (c.approvedBy.isNotEmpty()) "  by ${c.approvedBy}" else "", fontSize = 13.sp, color = Color.Gray)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { c.images.forEach { Preview(it.file, Modifier.weight(1f).height(230.dp)) } }
        c.images.forEach { Text("${it.lang.uppercase()}: ${it.l1} ${it.l2}", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
        c.images.firstOrNull()?.let { Text("Checks: ${it.qa}", fontSize = 11.sp, color = Color.Gray) }
        Spacer(Modifier.height(8.dp))
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (c.status == "awaiting_approval") Button(onClick = { confirm = true }) { Text("Approve") }
            OutlinedButton(enabled = !busy, onClick = { scope.launch { busy = true; Autopilot.regenerate(ctx, repo, c.id); busy = false } }) { Text("Regenerate") }
            OutlinedButton(enabled = !busy, onClick = { edit = true }) { Text("Edit text") }
        }
        if (c.status == "approved") {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                c.images.forEach { img -> OutlinedButton(onClick = { Sharing.share(ctx, File(img.file)) }) { Text("Share ${img.lang.uppercase()}") } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { send = true }) { Text("Send to contacts") }
                OutlinedButton(onClick = {
                    val ok = c.images.map { Sharing.saveToGallery(ctx, File(it.file)) }.all { it }
                    Toast.makeText(ctx, if (ok) "Saved to Pictures/FestiveStudio" else "Use Share to save on this Android version", Toast.LENGTH_SHORT).show()
                }) { Text("Save") }
            }
        } else Text("Sending is locked until you approve.", fontSize = 12.sp, color = Color.Gray)
    } }

    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("Approve these cards?") },
        text = { Text("${brandName(c.brand)} - ${occName(c.occasion)}. Your approval is recorded as \"${repo.ownerName}\" with the time. You can still choose who receives them.") },
        confirmButton = { Button(onClick = { Autopilot.approve(repo, c.id); confirm = false }) { Text("Approve") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })

    if (edit) EditDialog(c, onDismiss = { edit = false }) { en, hi ->
        edit = false
        scope.launch { busy = true; val ok = Autopilot.editText(ctx, repo, c.id, en, hi); busy = false
            if (!ok) Toast.makeText(ctx, "Text not accepted: use two short lines, Hindi in Devanagari, no promotional words", Toast.LENGTH_LONG).show() }
    }
    if (send) SendDialog(repo, c) { send = false }
}

@Composable
fun EditDialog(c: Campaign, onDismiss: () -> Unit, onSave: (Pair<String, String>, Pair<String, String>) -> Unit) {
    val en = c.images.find { it.lang == "en" }; val hi = c.images.find { it.lang == "hi" }
    var e1 by remember { mutableStateOf(en?.l1 ?: "") }; var e2 by remember { mutableStateOf(en?.l2 ?: "") }
    var h1 by remember { mutableStateOf(hi?.l1 ?: "") }; var h2 by remember { mutableStateOf(hi?.l2 ?: "") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit greeting") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            OutlinedTextField(e1, { e1 = it }, label = { Text("English line 1") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(e2, { e2 = it }, label = { Text("English line 2") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(h1, { h1 = it }, label = { Text("Hindi line 1") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(h2, { h2 = it }, label = { Text("Hindi line 2") }, modifier = Modifier.fillMaxWidth())
            Text("Saving re-creates both cards with your wording and cancels the earlier approval.", fontSize = 12.sp, color = Color.Gray)
        } },
        confirmButton = { Button(onClick = { onSave(e1.trim() to e2.trim(), h1.trim() to h2.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun SendDialog(repo: Repo, c: Campaign, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val people = Autopilot.eligibleContacts(repo, c)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Send via WhatsApp (manual)") },
        text = { Column {
            Text("WhatsApp opens with the card attached; you tap Send each time. Only contacts with consent and not opted out are listed (${people.size}).", fontSize = 12.sp)
            if (people.isEmpty()) Text("No eligible contacts for ${brandName(c.brand)}. Add contacts and tick their consent in the Contacts tab.", Modifier.padding(top = 8.dp))
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(people) { p ->
                    val img = c.images.find { it.lang == p.lang } ?: c.images.first()
                    val key = "${c.id}|${img.lang}|${p.phone}"
                    val done = key in repo.sentKeys
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.Bold); Text("${ContactImport.pretty(p.phone)} - ${img.lang.uppercase()}", fontSize = 12.sp) }
                        OutlinedButton(onClick = {
                            if (Sharing.sendToContact(ctx, File(img.file), p.phone, "")) {
                                if (!done) { repo.sentKeys.add(key); repo.save(); repo.audit(repo.ownerName, "opened_whatsapp", "campaign=${c.id} to=${p.phone}") }
                            } else Toast.makeText(ctx, "WhatsApp not found. Use Share instead.", Toast.LENGTH_LONG).show()
                        }) { Text(if (done) "Sent ✓ (again)" else "WhatsApp") }
                    }
                }
            }
        } },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}

// ------------------------------------------------------------------ CALENDAR
@Composable
fun CalendarScreen(repo: Repo) {
    val today = Autopilot.today()
    val upcoming = repo.events.filter { val d = LocalDate.parse(it.date); !d.isBefore(today.minusDays(3)) && d.isBefore(today.plusDays(366)) }.sortedBy { it.date }
    var setFor by remember { mutableStateOf<Event?>(null) }; var add by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Next 12 months", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Button(onClick = { add = true }) { Text("Add / confirm date") }
        }
        Text("Cards are made only for verified, fixed or owner-confirmed dates. Disputed dates wait for you.", fontSize = 12.sp, color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(upcoming) { e ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.nameEn} / ${e.nameHi}", fontWeight = FontWeight.Bold)
                        Text("${fmt(e.date)}  -  ${e.status}", fontSize = 13.sp, color = if (e.status == "disputed") Color(0xFFB00020) else Color.Gray)
                        Text(listOf(e.note, e.source).filter { it.isNotBlank() }.joinToString(" | "), fontSize = 11.sp, color = Color.Gray)
                        if (Messages.occasions[e.key] == null) Text("No greeting pack for this occasion yet", fontSize = 11.sp, color = Color(0xFFB00020))
                    }
                    if (e.status == "disputed" || e.status == "unconfirmed") TextButton(onClick = { setFor = e }) { Text("Set date") }
                } }
            }
        }
    }
    setFor?.let { e -> DateDialog("Confirm date for ${e.nameEn}", e.date, null, { setFor = null }) { _, d ->
        repo.putEvent(e.copy(date = d, status = "manual", source = "Confirmed by owner", note = ""), replaceKey = e.key + e.date)
        repo.audit(repo.ownerName, "confirm_date", "${e.key} -> $d"); setFor = null } }
    if (add) DateDialog("Add or confirm an occasion", today.toString(), Messages.occasions.values.sortedBy { it.nameEn }, { add = false }) { o, d ->
        if (o != null) { repo.putEvent(Event(o.key, d, o.nameEn, o.nameHi, "manual", "Entered by owner")); repo.audit(repo.ownerName, "add_date", "${o.key} $d") }
        add = false }
}

@Composable
fun DateDialog(title: String, initial: String, options: List<Occ>?, onDismiss: () -> Unit, onOk: (Occ?, String) -> Unit) {
    var d by remember { mutableStateOf(initial) }; var sel by remember { mutableStateOf(options?.firstOrNull()) }; var open by remember { mutableStateOf(false) }
    val valid = try { LocalDate.parse(d); true } catch (e: Exception) { false }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column {
            if (options != null) Box { OutlinedButton(onClick = { open = true }) { Text(sel?.nameEn ?: "Choose occasion") }
                DropdownMenu(open, { open = false }) { options.forEach { o -> DropdownMenuItem(text = { Text(o.nameEn) }, onClick = { sel = o; open = false }) } } }
            OutlinedTextField(d, { d = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true, isError = !valid)
            Text("Check the date in a trusted Panchang or calendar before confirming.", fontSize = 12.sp, color = Color.Gray)
        } },
        confirmButton = { Button(enabled = valid, onClick = { onOk(sel, d) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

// ------------------------------------------------------------------ CONTACTS
@Composable
fun ContactsScreen(repo: Repo) {
    val ctx = LocalContext.current
    var report by remember { mutableStateOf<ImportResult?>(null) }; var add by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            report = ContactImport.import(text, repo)
        } catch (e: Exception) { Toast.makeText(ctx, "Could not read that file", Toast.LENGTH_LONG).show() }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Contacts (${repo.contacts.size})", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Imported numbers are NOT consented by default. Tick consent only for people who agreed to receive your greetings.", fontSize = 12.sp, color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Import CSV") }
            OutlinedButton(onClick = { add = true }) { Text("Add contact") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(repo.contacts.toList()) { p ->
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                    Text(p.name, fontWeight = FontWeight.Bold)
                    Text("${ContactImport.pretty(p.phone)} - ${brandName(p.brand)} - ${p.lang.uppercase()}", fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(p.consent, { v -> val i = repo.contacts.indexOf(p); if (i >= 0) { repo.contacts[i] = p.copy(consent = v); repo.save() } }); Text("Consent", fontSize = 13.sp)
                        Spacer(Modifier.width(12.dp))
                        Checkbox(p.optedOut, { v -> val i = repo.contacts.indexOf(p); if (i >= 0) { repo.contacts[i] = p.copy(optedOut = v); repo.save() } }); Text("Opted out", fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { repo.contacts.remove(p); repo.save() }) { Text("Delete") }
                    }
                } }
            }
        }
    }
    report?.let { r -> AlertDialog(onDismissRequest = { report = null }, title = { Text("Import finished") },
        text = { Text("Added: ${r.added}\nDuplicates skipped: ${r.duplicates}\nInvalid numbers: ${r.invalid.size}" + if (r.invalid.isNotEmpty()) "\n\n" + r.invalid.take(5).joinToString("\n") else "") },
        confirmButton = { TextButton(onClick = { report = null }) { Text("OK") } }) }
    if (add) AddContactDialog({ add = false }) { n, ph, b, l ->
        val p = ContactImport.normalize(ph)
        if (p == null) Toast.makeText(ctx, "Invalid Indian mobile number", Toast.LENGTH_LONG).show()
        else if (repo.contacts.any { it.phone == p && it.brand == b }) Toast.makeText(ctx, "Already in the list", Toast.LENGTH_LONG).show()
        else { repo.contacts.add(Contact(n.ifBlank { ContactImport.pretty(p) }, p, b, l, false, false)); repo.save(); add = false }
    }
}

@Composable
fun AddContactDialog(onDismiss: () -> Unit, onAdd: (String, String, String, String) -> Unit) {
    var n by remember { mutableStateOf("") }; var ph by remember { mutableStateOf("") }; var b by remember { mutableStateOf("nector") }; var l by remember { mutableStateOf("en") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add contact") },
        text = { Column {
            OutlinedTextField(n, { n = it }, label = { Text("Name") }, singleLine = true)
            OutlinedTextField(ph, { ph = it }, label = { Text("Mobile / WhatsApp number") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Brands.all.forEach { br -> RadioButton(b == br.key, { b = br.key }); Text(br.name, fontSize = 12.sp) } }
            Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(l == "en", { l = "en" }); Text("English"); RadioButton(l == "hi", { l = "hi" }); Text("Hindi") }
            Text("New contacts start without consent.", fontSize = 12.sp, color = Color.Gray)
        } },
        confirmButton = { Button(onClick = { onAdd(n, ph, b, l) }) { Text("Add") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

// ------------------------------------------------------------------ SETTINGS
@Composable
fun SettingsScreen(repo: Repo) {
    val ctx = LocalContext.current
    var audit by remember { mutableStateOf<String?>(null) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(repo.ownerName, { repo.ownerName = it; repo.save() }, label = { Text("Your name (shown on approvals)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Daily generation time (IST): %02d:%02d".format(repo.notifyHour, repo.notifyMinute), fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { repo.notifyHour = (repo.notifyHour + 23) % 24; repo.save() }) { Text("Hour -") }
            OutlinedButton(onClick = { repo.notifyHour = (repo.notifyHour + 1) % 24; repo.save() }) { Text("Hour +") }
            OutlinedButton(onClick = { repo.notifyMinute = (repo.notifyMinute + 45) % 60; repo.save() }) { Text("Min -") }
            OutlinedButton(onClick = { repo.notifyMinute = (repo.notifyMinute + 15) % 60; repo.save() }) { Text("Min +") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(repo.thoughtEnabled, { repo.thoughtEnabled = it; repo.save() }); Spacer(Modifier.width(8.dp)); Text("Create a Thought of the Day every day")
        }
        if (Build.VERSION.SDK_INT >= 33) OutlinedButton(onClick = { perm.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications") }
        Divider()
        Text("Audit log: ${repo.auditCount()} entries", fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = { audit = if (repo.verifyAudit()) "Log is intact (hash chain verified)." else "WARNING: the log has been altered." }) { Text("Verify audit log") }
        audit?.let { Text(it) }
        repo.auditLines(8).forEach { Text(it, fontSize = 11.sp, color = Color.Gray) }
        Divider()
        Text("What this app does and does not do", fontWeight = FontWeight.Bold)
        Text("- Works fully offline on this phone. No server, no AI service, no WhatsApp API.\n" +
            "- Greetings come from a built-in writer with a limited set of lines per occasion; Hindi should be reviewed by a native speaker.\n" +
            "- Cards are created automatically, but nothing is sent without your approval, and sending is manual: WhatsApp opens and you tap Send.\n" +
            "- Product photos are not included yet.\n" +
            "- The background check runs about every 15 minutes at best; Android may delay it to save battery. Opening the app always catches up.", fontSize = 13.sp)
    }
}
