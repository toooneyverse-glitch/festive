# Festive Studio (Android, fully offline)

Creates Hindi + English greeting cards and a daily Thought of the Day for **Nector Industries** and **Carewell Pipes**,
on the phone itself. No server, no AI service, no WhatsApp API. You approve; you send.

## Build the APK
1. Install Android Studio (current stable). Open this folder (`FestiveStudio`). Let Gradle sync (needs internet once).
2. Plug in a phone (USB debugging) or start an emulator, press Run. Or: Build > Build Bundle(s)/APK(s) > Build APK(s).
3. Requires Android 8.0 or newer. For Hindi, any normal Android phone works (system Devanagari fonts).
4. First launch: Settings > enter your name, allow notifications.

> This project was written without access to an Android compiler. Expect to fix a few small compile errors on first sync;
> send them to me and I will correct them.

## Daily use
- App opens > it checks today's date and creates cards automatically (also a background check about every 15 min after your chosen time).
- Cards tab: Approve / Regenerate / Edit text. Sharing unlocks only after Approve.
- Contacts tab: import CSV (name, phone, brand, language, consent) or add one by one. Imported contacts have NO consent until you tick it.
- "Send to contacts": opens WhatsApp per person with the card attached; you tap Send. Nothing is sent automatically.
- Calendar tab: confirm disputed dates, or add a festival date from a Panchang you trust (needed for Holi, Raksha Bandhan, Ganesh Chaturthi, Dussehra, etc.).

## What is built in
- Verified dates: Dhanteras 6 Nov 2026, Diwali 8 Nov 2026. Disputed (needs your confirmation): Govardhan Puja, Bhai Dooj, Chhath Puja.
- Fixed-date days (every year): New Year, Republic Day, Women's Day, World Water Day, New Financial Year, Labour Day, World Environment Day,
  Independence Day, Teachers' Day, Engineers' Day, Gandhi Jayanti.
- Greeting packs for 23 occasions plus 12 Thought of the Day pairs, English and Hindi.

## Known limits
- Writing is rule-based (no AI model): limited wording per occasion; the app avoids repeating a pair for the same company until all are used.
- No product photos yet (add Nector tank / composite pipe photos to `app/src/main/assets` and I will wire them in).
- Nector logo file is small (200 px wide) and is enlarged ~1.7x, so it is slightly soft. Provide a larger original.
- WhatsApp per-contact sending uses WhatsApp's undocumented `jid` extra; if it stops working, use Share.
- No login/PIN, no Excel import, no delivery tracking (WhatsApp does not report back to the app).
- Hindi wording should be reviewed by a native speaker.
- The composite pipe brand name is intentionally never used anywhere.
